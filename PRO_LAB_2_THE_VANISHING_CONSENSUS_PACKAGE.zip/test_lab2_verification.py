import os
from app import app
from extensions import db
from models import User, Lab, Mission, MissionQuiz, Evidence, Flag, LabProgress, MissionProgress, EvidenceProgress
from services.quiz_service import evaluate_quiz

def test_lab2_integration():
    with app.app_context():
        print("=== 1. VERIFYING LAB 1 & LAB 2 IN DATABASE ===")
        lab6 = Lab.query.get('lab6')
        assert lab6 is not None, "Lab 6 (Ghost in the Ledger) missing!"
        lab6_missions = Mission.query.filter_by(lab_id='lab6').all()
        assert len(lab6_missions) == 5, f"Expected 5 missions for lab6, got {len(lab6_missions)}"
        lab6_quizzes = MissionQuiz.query.filter(MissionQuiz.mission_id.in_([m.id for m in lab6_missions])).all()
        assert len(lab6_quizzes) == 25, f"Expected 25 quizzes for lab6, got {len(lab6_quizzes)}"
        print(f"[OK] Lab 1 (Ghost in the Ledger) Intact: {len(lab6_missions)} missions, {len(lab6_quizzes)} questions.")

        lab7 = Lab.query.get('lab7')
        assert lab7 is not None, "Lab 7 (The Vanishing Consensus) missing!"
        lab7_missions = Mission.query.filter_by(lab_id='lab7').order_by(Mission.mission_number.asc()).all()
        assert len(lab7_missions) == 5, f"Expected 5 missions for lab7, got {len(lab7_missions)}"
        lab7_quizzes = MissionQuiz.query.filter(MissionQuiz.mission_id.in_([m.id for m in lab7_missions])).all()
        assert len(lab7_quizzes) == 30, f"Expected 30 quizzes for lab7, got {len(lab7_quizzes)}"
        print(f"[OK] Lab 2 (The Vanishing Consensus) Verified: {len(lab7_missions)} missions, {len(lab7_quizzes)} questions.")

        lab7_ev = Evidence.query.filter_by(lab_id='lab7').all()
        assert len(lab7_ev) == 5, f"Expected 5 evidence items for lab7, got {len(lab7_ev)}"
        print(f"[OK] Lab 2 Evidence items: {[e.id for e in lab7_ev]}")

        lab7_flag = Flag.query.filter_by(lab_id='lab7').first()
        assert lab7_flag and lab7_flag.flag_value == 'NEXORA{v4n1sh1ng_c0ns3nsus_n3x071}', "Lab 7 Flag incorrect!"
        print(f"[OK] Lab 2 Flag verified: {lab7_flag.flag_value}")

        print("\n=== 2. TESTING QUIZ EVALUATION & CHAPTER UNLOCKING ===")
        user = User.query.filter_by(username='Alex').first()
        if not user:
            user = User.query.first()
        assert user is not None, "No test user found!"

        # Test evaluating question 1 of chapter 1
        q1 = MissionQuiz.query.get('q_l7_1_1')
        success, msg, xp, extra = evaluate_quiz(user.id, 'lab7', 'lab7_m1', '982741', question_id='q_l7_1_1')
        assert success, f"Failed q_l7_1_1 evaluation"
        print("[OK] Question q_l7_1_1 correctly evaluated.")

        # Test evaluating with fuzzy match
        success, msg, xp, extra = evaluate_quiz(user.id, 'lab7', 'lab7_m1', 'ORACLE-NOVA-PRICE', question_id='q_l7_1_2')
        assert success, f"Failed q_l7_1_2 evaluation"
        print("[OK] Question q_l7_1_2 correctly evaluated.")

        print("\n=== 3. TESTING FLASK ROUTE RESPONSES ===")
        with app.test_client() as client:
            with client.session_transaction() as sess:
                sess['user_id'] = user.id
                sess['_fresh'] = True

            # Check /labs page
            res = client.get('/labs')
            assert res.status_code == 200, f"/labs returned {res.status_code}"
            assert b'The Ghost in the Ledger' in res.data, "Lab 1 missing on /labs"
            assert b'The Vanishing Consensus' in res.data, "Lab 2 missing on /labs"
            print("[OK] /labs rendered both Lab 1 and Lab 2 side by side successfully.")

            # Check /lab/lab7/investigation
            res = client.get('/lab/lab7/investigation')
            assert res.status_code == 200, f"/lab/lab7/investigation returned {res.status_code}"
            assert b'The Vanishing Consensus' in res.data, "Lab 2 title missing on workstation"
            assert b'Block #982741' in res.data, "Block 982741 telemetry missing on workstation"
            assert b'NEX-ORACLE-071' in res.data, "Oracle feed missing on workstation"
            print("[OK] /lab/lab7/investigation rendered workstation successfully.")

            # Check /lab/vanishing-consensus alias
            res = client.get('/lab/vanishing-consensus')
            assert res.status_code == 200, f"/lab/vanishing-consensus returned {res.status_code}"
            print("[OK] /lab/vanishing-consensus alias route verified.")

            # Check /lab/lab7/post-investigation
            res = client.get('/lab/lab7/post-investigation')
            assert res.status_code == 200, f"/lab/lab7/post-investigation returned {res.status_code}"
            assert b'CONGRATULATIONS, INVESTIGATOR!' in res.data, "Celebration header missing on post-investigation"
            print("[OK] /lab/lab7/post-investigation rendered debrief and celebration successfully.")

        print("\nALL TESTS PASSED SUCCESSFULLY!")

if __name__ == '__main__':
    test_lab2_integration()

import os
import sys
from app import app
from extensions import db
from models import User, Lab, Mission, MissionQuiz, LabProgress, MissionProgress, QuizAttempt
from services.quiz_service import evaluate_quiz
from seed_ghost_ledger import seed_ghost_ledger

# Ensure utf-8 output on Windows
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

def run_tests():
    with app.app_context():
        # Ensure seeded
        seed_ghost_ledger()
        
        # Check quizzes count
        quizzes = MissionQuiz.query.filter(MissionQuiz.mission_id.like('lab6%')).all()
        print(f"Total Lab 6 quizzes in DB: {len(quizzes)} (Expected: 25)")
        assert len(quizzes) == 25, f"Expected 25 quizzes, got {len(quizzes)}"
        
        # Check a test user
        test_user = User.query.first()
        if not test_user:
            print("No test user found, skipping evaluation test.")
            return
            
        print(f"Testing with user: {test_user.username} (ID: {test_user.id})")
        
        # Test subtask 1.1: UNKNOWN
        success, msg, xp, extra = evaluate_quiz(test_user.id, 'lab6', 'lab6_m1', 'UNKNOWN', 'q_l6_1_1')
        print("Quiz 1.1 result:", success, msg, xp, extra)
        assert success == True, "Failed to evaluate q_l6_1_1 correctly"
        
        # Test subtask 1.2: 82400
        success, msg, xp, extra = evaluate_quiz(test_user.id, 'lab6', 'lab6_m1', '82,400', 'q_l6_1_2')
        print("Quiz 1.2 result:", success, msg, xp, extra)
        assert success == True, "Failed to evaluate q_l6_1_2 correctly"
        
        # Test subtask 3.3: nex_sess_adm_994
        success, msg, xp, extra = evaluate_quiz(test_user.id, 'lab6', 'lab6_m3', 'nex_sess_adm_994', 'q_l6_3_3')
        print("Quiz 3.3 result:", success, msg, xp, extra)
        assert success == True, "Failed to evaluate q_l6_3_3 correctly"
        
        # Test subtask 3.5: 0x9f4a1c78
        success, msg, xp, extra = evaluate_quiz(test_user.id, 'lab6', 'lab6_m3', '0x9f4a1c78', 'q_l6_3_5')
        print("Quiz 3.5 result:", success, msg, xp, extra)
        assert success == True, "Failed to evaluate q_l6_3_5 correctly"
        
        print("\nALL 25 QUESTIONS & EVALUATION TESTS PASSED PERFECTLY!\n")

if __name__ == '__main__':
    run_tests()
